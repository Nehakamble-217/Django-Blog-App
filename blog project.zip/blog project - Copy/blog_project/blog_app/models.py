from django.db import models
from django.contrib.auth.models import User
from django_otp.models import Device

class Post(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

# class UserProfile(models.Model):
#     user = models.OneToOneField(User, on_delete=models.CASCADE)
#     otp_secret = models.CharField(max_length=16)
#     is_editor = models.BooleanField(default=False)
    
# blog_app/models.py
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    is_editor = models.BooleanField(default=False)

    def create_otp_device(self):
        return Device.objects.create(user=self.user, confirmed=True)
